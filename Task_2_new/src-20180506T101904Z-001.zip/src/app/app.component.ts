import { Component } from '@angular/core';
import {FilterPipe} from './pipes';

@Component({
  selector: 'pm-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {

}
